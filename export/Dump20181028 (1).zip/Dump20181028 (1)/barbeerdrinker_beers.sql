CREATE DATABASE  IF NOT EXISTS `barbeerdrinker` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `barbeerdrinker`;
-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: barbeerdrinker
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `beers`
--

DROP TABLE IF EXISTS `beers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `beers` (
  `name` varchar(100) NOT NULL,
  `manu` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beers`
--

LOCK TABLES `beers` WRITE;
/*!40000 ALTER TABLE `beers` DISABLE KEYS */;
INSERT INTO `beers` VALUES ('1664','Carlsberg Group'),('Agave Nectar Ale','Blue Moon Brewing Company'),('Alexander Keith&#8217;s beer range','Anheuser Busch Inbev'),('Amstel','Heineken International'),('Baltika','Carlsberg Group'),('Beck’s','Anheuser Busch Inbev'),('Beerlao','Carlsberg Group'),('Belgian Table Pils','Blue Moon Brewing Company'),('Belle','Vue'),('Birra Moretti','Heineken International'),('Blackberry Tart Ale','Blue Moon Brewing Company'),('Blue Moon','Blue Moon Brewing Company'),('Blue Moon Grand Cru','Blue Moon Brewing Company'),('Blue Moon Pale Ale','Blue Moon Brewing Company'),('Blue Sword','CR Snow'),('Bosman','Carlsberg Group'),('Brahma','Anheuser Busch Inbev'),('Bud Light','Anheuser Busch Inbev'),('Budweiser','Anheuser Busch Inbev'),('Busch','Anheuser Busch Inbev'),('Cappuccino Oatmeal Stout','Blue Moon Brewing Company'),('Caramel Apple Spiced Ale','Blue Moon Brewing Company'),('Carlsberg','Carlsberg Group'),('Chai Spiced Ale','Blue Moon Brewing Company'),('Chernihivske','Anheuser Busch Inbev'),('Cinnamon Horchata Ale','Blue Moon Brewing Company'),('Cocoa Brown Ale','Blue Moon Brewing Company'),('Colt 45','Pabst Brewing Co.'),('Corona','Anheuser Busch Inbev'),('Cruzcampo','Heineken International'),('Devils Backbone Brewing Company','Anheuser Busch Inbev'),('Dos Equis XX','Heineken International'),('Elephant Beer','Carlsberg Group'),('Elysian Brewing Company','Anheuser Busch Inbev'),('Farmhouse Red Ale','Blue Moon Brewing Company'),('Feldschlösschen','Carlsberg Group'),('Four Peaks','Anheuser Busch Inbev'),('Gingerbread Spiced Ale','Blue Moon Brewing Company'),('Golden Road','Anheuser Busch Inbev'),('Goose Island Brewery','Anheuser Busch Inbev'),('Gorkha Beer','Carlsberg Group'),('Green Leaves','CR Snow'),('Grimbergen','Carlsberg Group'),('Harvest Pumpkin Ale','Blue Moon Brewing Company'),('Heineken Lager Beer','Heineken International'),('Hoegaarden','Anheuser Busch Inbev'),('Huadan','CR Snow'),('Jacobsen','Carlsberg Group'),('Karbach Brewing Company','Anheuser Busch Inbev'),('Kokanee beers','Anheuser Busch Inbev'),('Kronenbourg','Carlsberg Group'),('Labatt Family','Anheuser Busch Inbev'),('Lakeport Brewing beer range','Anheuser Busch Inbev'),('Largo','CR Snow'),('Lav','Carlsberg Group'),('Leffe','Anheuser Busch Inbev'),('Lone Star','Pabst Brewing Co.'),('Mountain Abbey Ale','Blue Moon Brewing Company'),('Murphy’s','Heineken International'),('National Bohemian Beer','Pabst Brewing Co.'),('Newcastle Brown Ale','Heineken International'),('Nut Brown Ale','Blue Moon Brewing Company'),('Ochota','Heineken International'),('Pan','Carlsberg Group'),('Past Blue Ribbon','Pabst Brewing Co.'),('Peanut Butter Ale','Blue Moon Brewing Company'),('Pearl Lager Beer','Pabst Brewing Co.'),('Rainer Beer','Pabst Brewing Co.'),('Raspberry Cream Ale','Blue Moon Brewing Company'),('Rounder Belgian','Style Pale'),('Schaefer Beer','Pabst Brewing Co.'),('Schmidt’s Premium Beer','Pabst Brewing Co.'),('Shenyang','CR Snow'),('Singo','CR Snow'),('Skol','Anheuser Busch Inbev'),('Snow','CR Snow'),('Special Brew','Carlsberg Group'),('Spiced Amber Ale','Blue Moon Brewing Company'),('Spring Blonde Wheat Ale','Blue Moon Brewing Company'),('Stag Beer','Pabst Brewing Co.'),('Star','Heineken International'),('Starobrno','Heineken International'),('Stella Artois','Anheuser Busch Inbev'),('Stroh’s','Pabst Brewing Co.'),('Summer Honey Wheat Ale','Blue Moon Brewing Company'),('Sunshine Citrus Blonde','Blue Moon Brewing Company'),('Tiger Beer','Heineken International'),('Valencia Amber Ale','Blue Moon Brewing Company'),('White IPA','Blue Moon Brewing Company'),('Zagorka','Heineken International');
/*!40000 ALTER TABLE `beers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-28 22:03:07
