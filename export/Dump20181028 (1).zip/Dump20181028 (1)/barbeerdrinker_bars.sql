CREATE DATABASE  IF NOT EXISTS `barbeerdrinker` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `barbeerdrinker`;
-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: barbeerdrinker
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bars`
--

DROP TABLE IF EXISTS `bars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bars` (
  `name` varchar(100) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `owner_first` varchar(100) DEFAULT NULL,
  `owner_last` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bars`
--

LOCK TABLES `bars` WRITE;
/*!40000 ALTER TABLE `bars` DISABLE KEYS */;
INSERT INTO `bars` VALUES ('Black Horse','Union','815-178-9348','Roger','Tia'),('Callahan\'s Place','Fort Lee','201-468-7437','Gabriel','Lily'),('Gateway Inn','East Brunswick','848-526-9544','Vern','Robin'),('McGinty\'s','West New York','201-978-5424','Antoinette','Joan'),('Mulberry Street Bar','Hackensack','551-801-9692','Dan','Kristine'),('Pedro McKinnon','Fort Lee','201-766-5843','Lou','Beatrice'),('Scarlet Raven Tavern','North Bergen','201-726-8257','Kenny','Thurman'),('The Bamboo Lounge','Clifton','862-327-2921','Patricia','Maurice'),('The Blue Oyster Bar','Plainfield','908-151-8047','Millie','Conrad'),('The Cat & Fiddle','Union','815-464-3969','Brianna','Phyllis'),('The Eolian','Belleville','613-153-0078','Wade','Blake'),('The Grasshopper','Bloomfield','973-316-1025','Celia','Flora'),('The Lizard\'s Head','West New York','201-578-4155','Adela','Lorie'),('Thunderbrew Distillery','Newark','973-814-8482','Avery','Larry'),('Y Deri Arms','Fort Lee','201-630-2704','Deirdre','Suzanne');
/*!40000 ALTER TABLE `bars` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-28 22:03:06
