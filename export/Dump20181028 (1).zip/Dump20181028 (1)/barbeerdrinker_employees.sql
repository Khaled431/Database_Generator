CREATE DATABASE  IF NOT EXISTS `barbeerdrinker` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `barbeerdrinker`;
-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: barbeerdrinker
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `employees` (
  `bar_name` varchar(100) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `shift_hour_start` int(11) DEFAULT NULL,
  `shift_hour_end` int(11) DEFAULT NULL,
  `shift_day_of_week` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bar_name`,`first_name`,`last_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('Black Horse','Alexander','Javier',16,24,'MONDAY'),('Black Horse','Evangelina','Phillip',17,27,'SATURDAY'),('Black Horse','Fredrick','Cary',9,17,'FRIDAY'),('Black Horse','Hannah','Cathleen',17,27,'SUNDAY'),('Black Horse','Jay','Lizzie',17,27,'FRIDAY'),('Black Horse','Manuela','Roslyn',9,17,'SATURDAY'),('Black Horse','Reynaldo','Weldon',16,24,'TUESDAY'),('Black Horse','Sierra','Addie',16,24,'WEDNESDAY'),('Black Horse','Trenton','Houston',16,24,'THURSDAY'),('Black Horse','Xavier','Elisha',9,17,'SUNDAY'),('Callahan\'s Place','Amparo','Shawn',9,17,'SATURDAY'),('Callahan\'s Place','Clarice','Jose',17,27,'SUNDAY'),('Callahan\'s Place','Darnell','Carmela',9,17,'SUNDAY'),('Callahan\'s Place','Dena','Carolyn',16,24,'WEDNESDAY'),('Callahan\'s Place','Jim','Lincoln',16,24,'MONDAY'),('Callahan\'s Place','Ned','Christina',9,17,'FRIDAY'),('Callahan\'s Place','Owen','Sherri',16,24,'TUESDAY'),('Callahan\'s Place','Ruthie','Clinton',17,27,'SATURDAY'),('Callahan\'s Place','Terrell','Shelia',17,27,'FRIDAY'),('Callahan\'s Place','Willa','Antoine',16,24,'THURSDAY'),('Gateway Inn','Brock','Gabriela',16,24,'THURSDAY'),('Gateway Inn','Carroll','Darrin',9,17,'FRIDAY'),('Gateway Inn','Claudia','Alisha',17,27,'SUNDAY'),('Gateway Inn','Dianna','Hollis',17,27,'FRIDAY'),('Gateway Inn','Guillermo','Felicia',9,17,'SATURDAY'),('Gateway Inn','Heriberto','Etta',17,27,'SATURDAY'),('Gateway Inn','Millicent','Bret',16,24,'WEDNESDAY'),('Gateway Inn','Rosalind','Anna',16,24,'MONDAY'),('Gateway Inn','Selena','Jacquelyn',9,17,'SUNDAY'),('Gateway Inn','Simone','Chad',16,24,'TUESDAY'),('McGinty\'s','Clement','Aurelia',16,24,'MONDAY'),('McGinty\'s','Donna','Bettye',16,24,'WEDNESDAY'),('McGinty\'s','Flossie','Josh',17,27,'FRIDAY'),('McGinty\'s','Gabrielle','Marva',16,24,'TUESDAY'),('McGinty\'s','Jake','Doretha',9,17,'FRIDAY'),('McGinty\'s','Loyd','Leeann',9,17,'SUNDAY'),('McGinty\'s','Lucile','Ivan',17,27,'SUNDAY'),('McGinty\'s','Pansy','Brendan',17,27,'SATURDAY'),('McGinty\'s','Samuel','Emilio',16,24,'THURSDAY'),('McGinty\'s','Shane','Reynaldo',9,17,'SATURDAY'),('Mulberry Street Bar','Annie','Evangelina',9,17,'SUNDAY'),('Mulberry Street Bar','Christy','Doyle',9,17,'FRIDAY'),('Mulberry Street Bar','Heather','Juan',16,24,'TUESDAY'),('Mulberry Street Bar','Janis','Matthew',16,24,'THURSDAY'),('Mulberry Street Bar','Jay','Jeri',9,17,'SATURDAY'),('Mulberry Street Bar','Margot','Jami',17,27,'SUNDAY'),('Mulberry Street Bar','Rickie','Pansy',16,24,'MONDAY'),('Mulberry Street Bar','Wendell','Cornelius',17,27,'SATURDAY'),('Mulberry Street Bar','Willard','Irving',17,27,'FRIDAY'),('Mulberry Street Bar','Wilma','Sebastian',16,24,'WEDNESDAY'),('Pedro McKinnon','Blake','Marlene',16,24,'TUESDAY'),('Pedro McKinnon','Christian','Ernesto',9,17,'SUNDAY'),('Pedro McKinnon','Gayla','Genaro',16,24,'THURSDAY'),('Pedro McKinnon','Jordan','Wanda',16,24,'MONDAY'),('Pedro McKinnon','Latisha','Araceli',16,24,'WEDNESDAY'),('Pedro McKinnon','Mark','Caitlin',17,27,'SATURDAY'),('Pedro McKinnon','Noreen','Carlos',17,27,'FRIDAY'),('Pedro McKinnon','Ophelia','Natalia',17,27,'SUNDAY'),('Pedro McKinnon','Rhea','Efrain',9,17,'FRIDAY'),('Pedro McKinnon','Thurman','Cornelia',9,17,'SATURDAY'),('Scarlet Raven Tavern','Blanche','Doug',9,17,'SATURDAY'),('Scarlet Raven Tavern','Clint','Iris',17,27,'FRIDAY'),('Scarlet Raven Tavern','Errol','Freddie',9,17,'FRIDAY'),('Scarlet Raven Tavern','Freddie','Elba',16,24,'TUESDAY'),('Scarlet Raven Tavern','Gail','Katrina',16,24,'MONDAY'),('Scarlet Raven Tavern','Gilbert','Mara',16,24,'WEDNESDAY'),('Scarlet Raven Tavern','Marlin','Tabitha',16,24,'THURSDAY'),('Scarlet Raven Tavern','Ron','Camilla',17,27,'SATURDAY'),('Scarlet Raven Tavern','Ross','Emanuel',17,27,'SUNDAY'),('Scarlet Raven Tavern','Stewart','Jeremy',9,17,'SUNDAY'),('The Bamboo Lounge','Arthur','Ismael',16,24,'MONDAY'),('The Bamboo Lounge','Bernadette','Lloyd',16,24,'TUESDAY'),('The Bamboo Lounge','Ed','Shari',16,24,'WEDNESDAY'),('The Bamboo Lounge','Ella','Alexander',17,27,'SATURDAY'),('The Bamboo Lounge','Janine','Aline',9,17,'SUNDAY'),('The Bamboo Lounge','Judy','Natasha',9,17,'FRIDAY'),('The Bamboo Lounge','Lenora','Nan',9,17,'SATURDAY'),('The Bamboo Lounge','Margaret','Berta',17,27,'FRIDAY'),('The Bamboo Lounge','Myrtle','Matthew',17,27,'SUNDAY'),('The Bamboo Lounge','Roslyn','Sasha',16,24,'THURSDAY'),('The Blue Oyster Bar','Barry','Gussie',16,24,'MONDAY'),('The Blue Oyster Bar','Brian','Booker',16,24,'WEDNESDAY'),('The Blue Oyster Bar','Brigitte','Davis',9,17,'SATURDAY'),('The Blue Oyster Bar','Dwayne','Brian',9,17,'SUNDAY'),('The Blue Oyster Bar','Elaine','Wilmer',17,27,'FRIDAY'),('The Blue Oyster Bar','Fredrick','Stacy',16,24,'THURSDAY'),('The Blue Oyster Bar','Luis','Roxanne',16,24,'TUESDAY'),('The Blue Oyster Bar','Mandy','Malinda',17,27,'SUNDAY'),('The Blue Oyster Bar','Monika','Alexandra',17,27,'SATURDAY'),('The Blue Oyster Bar','Ulysses','Luisa',9,17,'FRIDAY'),('The Cat & Fiddle','Alberta','Jacqueline',9,17,'SATURDAY'),('The Cat & Fiddle','Buddy','Camille',17,27,'SUNDAY'),('The Cat & Fiddle','Carla','Horace',9,17,'FRIDAY'),('The Cat & Fiddle','Edward','Derek',9,17,'SUNDAY'),('The Cat & Fiddle','Ervin','Crystal',16,24,'MONDAY'),('The Cat & Fiddle','Jimmy','Concepcion',16,24,'TUESDAY'),('The Cat & Fiddle','Justina','Heather',17,27,'FRIDAY'),('The Cat & Fiddle','Ross','Betty',16,24,'WEDNESDAY'),('The Cat & Fiddle','Ruth','Trisha',16,24,'THURSDAY'),('The Cat & Fiddle','Tamara','Luann',17,27,'SATURDAY'),('The Eolian','Bobbi','Vilma',16,24,'THURSDAY'),('The Eolian','Collin','Eddy',17,27,'SATURDAY'),('The Eolian','Gena','Leonardo',16,24,'TUESDAY'),('The Eolian','Jami','Jade',17,27,'FRIDAY'),('The Eolian','Josefa','Dorothy',9,17,'SATURDAY'),('The Eolian','Kenny','Thurman',9,17,'SUNDAY'),('The Eolian','Melba','Leanna',16,24,'MONDAY'),('The Eolian','Melva','Ella',16,24,'WEDNESDAY'),('The Eolian','Monika','Jeremy',9,17,'FRIDAY'),('The Eolian','Trent','Colby',17,27,'SUNDAY'),('The Grasshopper','Arron','Ora',16,24,'TUESDAY'),('The Grasshopper','Brittany','Kristi',9,17,'FRIDAY'),('The Grasshopper','Chase','Tyrone',17,27,'SUNDAY'),('The Grasshopper','Deirdre','Suzanne',16,24,'THURSDAY'),('The Grasshopper','Donny','Melinda',17,27,'FRIDAY'),('The Grasshopper','Gerardo','Renae',16,24,'MONDAY'),('The Grasshopper','Juana','Cory',9,17,'SATURDAY'),('The Grasshopper','Kitty','Chase',9,17,'SUNDAY'),('The Grasshopper','Tanisha','Rosalinda',16,24,'WEDNESDAY'),('The Grasshopper','Thurman','Leeann',17,27,'SATURDAY'),('The Lizard\'s Head','Amie','Javier',16,24,'TUESDAY'),('The Lizard\'s Head','Archie','Rosa',9,17,'SUNDAY'),('The Lizard\'s Head','Deirdre','Helga',9,17,'FRIDAY'),('The Lizard\'s Head','Greg','Angeline',9,17,'SATURDAY'),('The Lizard\'s Head','Kaitlin','Loyd',17,27,'SUNDAY'),('The Lizard\'s Head','Landon','Janell',16,24,'THURSDAY'),('The Lizard\'s Head','Lindsay','Fern',17,27,'SATURDAY'),('The Lizard\'s Head','Millie','Conrad',17,27,'FRIDAY'),('The Lizard\'s Head','Stan','Gregorio',16,24,'MONDAY'),('The Lizard\'s Head','Sybil','Vanessa',16,24,'WEDNESDAY'),('Thunderbrew Distillery','Alison','Edith',16,24,'MONDAY'),('Thunderbrew Distillery','Charles','Kristine',16,24,'TUESDAY'),('Thunderbrew Distillery','Clair','Kelli',9,17,'SUNDAY'),('Thunderbrew Distillery','Collin','Diana',17,27,'SATURDAY'),('Thunderbrew Distillery','Daisy','Ursula',16,24,'THURSDAY'),('Thunderbrew Distillery','Delmar','Polly',17,27,'SUNDAY'),('Thunderbrew Distillery','Felicia','Alba',9,17,'FRIDAY'),('Thunderbrew Distillery','Marlin','Winfred',17,27,'FRIDAY'),('Thunderbrew Distillery','Phil','Martha',9,17,'SATURDAY'),('Thunderbrew Distillery','Rhea','Leila',16,24,'WEDNESDAY'),('Y Deri Arms','Abby','Marc',16,24,'MONDAY'),('Y Deri Arms','Adeline','Hillary',17,27,'SUNDAY'),('Y Deri Arms','Gayla','Dwayne',16,24,'TUESDAY'),('Y Deri Arms','Georgia','Rene',9,17,'SATURDAY'),('Y Deri Arms','Gladys','Gale',17,27,'SATURDAY'),('Y Deri Arms','Jeff','Angelia',9,17,'SUNDAY'),('Y Deri Arms','Linda','Florine',16,24,'THURSDAY'),('Y Deri Arms','Nelson','Kristina',9,17,'FRIDAY'),('Y Deri Arms','Nicholas','Lelia',16,24,'WEDNESDAY'),('Y Deri Arms','Terrie','Garland',17,27,'FRIDAY');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-28 22:03:07
